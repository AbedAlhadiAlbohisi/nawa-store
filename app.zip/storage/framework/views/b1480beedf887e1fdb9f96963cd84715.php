<?php $__env->startSection('content'); ?>
<div class="container">
  <h2 class="mb-4 fs-3">
    <?= $title ?>
  </h2>
  <a class="btn btn-primary m-5" href="<?php echo e(route("categories.create")); ?>" role="button">Create Proudct</a>
  <table class="table">
    <thead>
      <tr>
        <th>Id</th>
        <th>Name</th>
        <th>Edit</th>
        <th>Delete</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td>
          <?php echo e($category->id); ?>

        </td>
        <td>
          <?php echo e($category->name); ?>

        </td>
        <td><a href="<?php echo e(route('categories.edit' ,$category->id)); ?>" class="btn btn-sm btn-outline-dark"><i
              class="far fa-edit"></i> Edit</a></td>
        <td>
          <form action="<?php echo e(route('categories.destroy',$category->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"> delete</i></button>
          </form>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\nawa-store\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>