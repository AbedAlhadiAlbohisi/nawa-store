<?php $__env->startSection('content'); ?>

<div class="card card-primary">
    <div class="card-header">
        <h3 class="card-title">Create Products</h3>
    </div>
</div>
      <form action="<?php echo e(route('products.store',$product->id)); ?>"
        method="post" enctype="multipart/form-data">
         <?php echo csrf_field(); ?>
                    <?php echo $__env->make('admin.products._form',[
                        'submit_label'=>'save'
                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\nawa-store\resources\views/admin/products/create.blade.php ENDPATH**/ ?>