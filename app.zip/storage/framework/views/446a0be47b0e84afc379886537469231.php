<?php $__env->startSection('content'); ?>
<section class="content">
    <header class="mb-4 d-flex">
        <h2 class="mb-4 fs-3"> <?php echo e($title); ?> </h2>
        <div class="ml-auto">
            <a href="<?php echo e(route("products.index")); ?>" class="btn btn-sm btn-primary">Products List</a>
        </div>
    </header>
    <div class="row">

        

        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title"><?php echo e($title); ?></h3>
                </div>
                   <!-- /.card-header -->
                   <div class="card-body">
                    <?php if(session()->has('success')): ?>
                     <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                     </div>
                    <?php endif; ?>
                     <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Image</th>
                                <th>Name</th>
                                <th>Deleted_at</th>
                                <th>Settings</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tr>
                                 <td><?php echo e($loop->index + 1 ?? ''); ?></td>
                                 <td>
                                     <a href="<?php echo e($product->image_url); ?>">
                                        <img src="<?php echo e($product->image_url); ?>" alt="" width="60">
                                     </a>
                                 </td>
                                 <td><?php echo e($product->name); ?></td>

                                 <td><?php echo e($product->deleted_at); ?></td>


                                 <td>
                                        <div class="btn-group">
                                            <form method="POST" action="<?php echo e(route('products.restore',$product->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('put'); ?>
                                                <button type="submit" class="btn btn-primary">
                                                    <i class="fas fa-trash-restore"></i>Restore</button>
                                            </form>
                                            <form method="POST" action="<?php echo e(route('products.force-delete',$product->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger">
                                                    <i class="fas fa-trash"></i>Force Delete</button>
                                            </form>
                                        </div>


                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                </div>
            </div>
        </div>
    </div>
    <?php echo e($products->links()); ?>

</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\nawa-store\resources\views/admin/products/trashed.blade.php ENDPATH**/ ?>